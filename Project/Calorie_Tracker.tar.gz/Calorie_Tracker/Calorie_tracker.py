from flask import Flask,render_template,request,redirect
from pymongo import MongoClient
from flask import Flask,jsonify
from datetime import datetime

app = Flask(__name__)

@app.route('/')
def Calorie():
   return render_template('index.html')


@app.route('/add',methods=['GET','POST'])
def add_data():
    if request.method == "POST":
        date = request.form['date']
        food_item = request.form['food_item']
        protein = float(request.form['protein'])
        fat = float(request.form['fat'])
        Carbs = float(request.form['Carbs'])
        calorie_intake = protein*4 + fat*4 + Carbs*9
        data_dic = {'date' : date,'food_item':food_item ,'protein':protein,'fat':fat,'Carbs':Carbs,'calorie_intake':calorie_intake}
        collection.insert_one(data_dic)
        return redirect('/home')

    return render_template('add.html')



@app.route('/home')
def home():
    data1 = collection.find().sort('date', -1)
    return render_template('homepage.html', data = data1)


@app.route("/update/<string:date>/<string:food_item>",methods=['GET','POST'])
def update(date,food_item):
    if request.method == "POST":
        date = request.form['date']
        food_item = request.form['food_item']
        protein = float(request.form['protein'])
        fat = float(request.form['fat'])
        Carbs = float(request.form['Carbs'])
        calorie_intake = protein*4 + fat*4 + Carbs*9
        data_dic = {'date' : date,'food_item':food_item ,'protein':protein,'fat':fat,'Carbs':Carbs,'calorie_intake':calorie_intake}
        collection.update_one({'date':date,'food_item':food_item},{'$set' :{'date':date,'food_item':food_item ,'protein':protein,'fat':fat,'Carbs':Carbs,'calorie_intake':calorie_intake}})
        return redirect('/home')

    up_docs = collection.find({'date':date,'food_item':food_item})
    return render_template('update.html',docs = up_docs)


""" @app.route("/home/<string:date>/<string:food_item>",methods = ['PUT'])
def update(date,food_item):
    collection.update_one({'date':date,'food_item':food_item},{'$set':{'fat': 67}})
    return jsonify({'date':date,'food_item':food_item})  """



@app.route("/delete/<string:date>/<string:food_item>",methods =['GET'])
def delete_data(date,food_item):
    collection.delete_one({'date':date,'food_item':food_item})
    return redirect('/home') 


""" @app.route("/home/<string:date>", methods=['DELETE'])
def delete(date):
    collection.delete_many({'date': date,'food_item':food_item})
    return jsonify({'result' : True}) """




if __name__ == "__main__":
    client = MongoClient("mongodb://localhost:27017")
    db=client['calorie_tracker']
    collection=db['CalCollection']
    app.run(host = '0.0.0.0', debug=True, port=8080)
